#include<stdio.h>

int main()
{
int n;
int x;
int a;

	printf("enter number:\n");
	scanf("%d",&n);
a=n;
x=0;
while (a > x) {
		while (n > x)
		{
			printf(" ");
			n -= 1;
		}
	printf("*\n");
	a -= 1;
	n=a;

}}



