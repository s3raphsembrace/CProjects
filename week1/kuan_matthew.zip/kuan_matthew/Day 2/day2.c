#include <stdio.h>

int main()
{
	int x = 9, y = 3;
	printf("%d / %d = %f",x,y,(float)x/y)
	return 0;
}