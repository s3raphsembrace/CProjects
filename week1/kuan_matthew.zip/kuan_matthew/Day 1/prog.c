#include <stdio.h>

int main()
{
	printf("Hello World! \n Today is a good day. \n");
	return 0;
}