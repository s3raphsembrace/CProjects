#include<stdio.h>

float main()
{
	printf("Enter two numbers to add:");
		scanf("%d", &x);
		scanf("%d", &y);
float sum = ("%d + %d",x+y);
float diff = ("%d - %d",x-y);
float prod = ("%d * %d",x*y);
float quo = ("%d / %d",x/y);
	printf("The sum is " sum "\n")
	printf("The difference is " diff "\n")
	printf("The product is " prod "\n")
	printf("The quotient is " quo "\n")
	return 0;
}
// sum diff product and quotient